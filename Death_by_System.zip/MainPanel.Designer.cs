﻿namespace Death_by_System
{
    partial class MainPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelCTN = new Panel();
            SuspendLayout();
            // 
            // panelCTN
            // 
            panelCTN.Dock = DockStyle.Fill;
            panelCTN.Location = new Point(0, 0);
            panelCTN.Margin = new Padding(3, 4, 3, 4);
            panelCTN.Name = "panelCTN";
            panelCTN.Size = new Size(1200, 676);
            panelCTN.TabIndex = 0;
            panelCTN.Paint += panelCTN_Paint;
            // 
            // MainPanel
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 676);
            Controls.Add(panelCTN);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Margin = new Padding(3, 4, 3, 4);
            Name = "MainPanel";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Death by System";
            Load += MainPanel_Load;
            ResumeLayout(false);
        }

        #endregion

        public Panel panelCTN;
    }
}